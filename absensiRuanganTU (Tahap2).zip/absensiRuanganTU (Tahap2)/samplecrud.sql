CREATE TABLE restexamplecrud 
(id serial PRIMARY KEY NOT NULL,
key varchar(100) NOT NULL,
value varchar(250) NOT NULL,
rand smallint NOT NULL,
nama varchar(250) NOT NULL,
waktu_input varchar (250) NOT NULL 
);