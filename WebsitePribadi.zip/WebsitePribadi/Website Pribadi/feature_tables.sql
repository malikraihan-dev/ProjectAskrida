-- =============================================
-- SQL Tables for New Features
-- 5. Real Estate Listing
-- 6. Project Management Tool
-- 7. Chatbot Interface
-- =============================================

-- ===== 5. REAL ESTATE LISTING =====
CREATE TABLE IF NOT EXISTS property_listing (
    id_property SERIAL PRIMARY KEY,
    judul VARCHAR(255) NOT NULL,
    deskripsi TEXT,
    tipe_properti VARCHAR(50) NOT NULL, -- 'Rumah', 'Apartemen', 'Ruko', 'Tanah', 'Kos'
    harga BIGINT NOT NULL,
    luas_tanah INT, -- m2
    luas_bangunan INT, -- m2
    jumlah_kamar INT DEFAULT 0,
    jumlah_kamar_mandi INT DEFAULT 0,
    alamat TEXT NOT NULL,
    kota VARCHAR(100) NOT NULL,
    provinsi VARCHAR(100),
    status_listing VARCHAR(20) DEFAULT 'Tersedia', -- 'Tersedia', 'Terjual', 'Disewa'
    nama_pemilik VARCHAR(255),
    telepon_pemilik VARCHAR(20),
    gambar_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 6. PROJECT MANAGEMENT TOOL =====
CREATE TABLE IF NOT EXISTS projects (
    id_project SERIAL PRIMARY KEY,
    nama_project VARCHAR(255) NOT NULL,
    deskripsi TEXT,
    status_project VARCHAR(30) DEFAULT 'Planning', -- 'Planning', 'In Progress', 'Review', 'Completed', 'On Hold'
    prioritas VARCHAR(20) DEFAULT 'Medium', -- 'Low', 'Medium', 'High', 'Critical'
    tanggal_mulai DATE,
    tanggal_selesai DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS project_tasks (
    id_task SERIAL PRIMARY KEY,
    id_project INT NOT NULL REFERENCES projects(id_project) ON DELETE CASCADE,
    judul_task VARCHAR(255) NOT NULL,
    deskripsi TEXT,
    status_task VARCHAR(30) DEFAULT 'To Do', -- 'To Do', 'In Progress', 'Done'
    prioritas VARCHAR(20) DEFAULT 'Medium',
    assignee VARCHAR(255),
    tanggal_deadline DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 7. CHATBOT INTERFACE =====
CREATE TABLE IF NOT EXISTS chat_messages (
    id_message SERIAL PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    sender VARCHAR(10) NOT NULL, -- 'user' or 'bot'
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chatbot_responses (
    id_response SERIAL PRIMARY KEY,
    keyword VARCHAR(100) NOT NULL,
    response TEXT NOT NULL,
    kategori VARCHAR(50)
);

-- Insert default chatbot responses
INSERT INTO chatbot_responses (keyword, response, kategori) VALUES
('halo', 'Halo! Selamat datang. Ada yang bisa saya bantu?', 'greeting'),
('hai', 'Hai! Ada yang bisa saya bantu hari ini?', 'greeting'),
('selamat pagi', 'Selamat pagi! Semoga hari Anda menyenangkan. Ada yang bisa dibantu?', 'greeting'),
('selamat siang', 'Selamat siang! Ada yang bisa saya bantu?', 'greeting'),
('selamat sore', 'Selamat sore! Ada yang bisa saya bantu?', 'greeting'),
('selamat malam', 'Selamat malam! Ada yang bisa saya bantu?', 'greeting'),
('absensi', 'Untuk melakukan absensi, silakan kunjungi halaman Dashboard dan gunakan fitur Absensi Cepat dengan memasukkan NIM Anda.', 'info'),
('ruangan', 'Terdapat 4 ruangan yang tersedia untuk absensi. Anda bisa melihat detail ruangan di halaman Dashboard.', 'info'),
('properti', 'Untuk melihat daftar properti, silakan kunjungi halaman Real Estate Listing di sidebar menu.', 'info'),
('project', 'Untuk mengelola project, silakan kunjungi halaman Project Management di sidebar menu.', 'info'),
('bantuan', 'Saya bisa membantu Anda dengan informasi tentang: absensi, ruangan, properti, project, dan lainnya. Silakan tanyakan!', 'help'),
('help', 'Berikut yang bisa saya bantu:\n1. Informasi Absensi\n2. Info Ruangan\n3. Info Properti\n4. Info Project Management\n5. Bantuan Umum\nSilakan ketik topik yang ingin ditanyakan!', 'help'),
('terima kasih', 'Sama-sama! Jangan ragu untuk bertanya lagi ya.', 'greeting'),
('makasih', 'Sama-sama! Semoga membantu.', 'greeting'),
('bye', 'Sampai jumpa! Semoga hari Anda menyenangkan.', 'greeting'),
('jam', 'Jam operasional kampus adalah Senin-Jumat pukul 07:00 - 17:00 WIB dan Sabtu pukul 07:00 - 12:00 WIB.', 'info'),
('kontak', 'Untuk informasi kontak, silakan hubungi bagian TU di ext. 123 atau email tu@kampus.ac.id', 'info');
