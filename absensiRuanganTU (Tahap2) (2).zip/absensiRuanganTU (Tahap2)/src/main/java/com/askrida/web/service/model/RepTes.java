package com.askrida.web.service.model;

public class RepTes {
	

}
